


#!/bin/bash
apt install neofetch
clear
echo "----------------------------------------------"
echo ""
apt install php
clear
echo "--------------now exit--------------------------"
echo ""

sleep 4
clear
